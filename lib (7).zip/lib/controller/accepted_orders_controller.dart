import 'package:get/get.dart';

class AcceptedOrdersController extends GetxController{

}