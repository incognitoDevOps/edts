const Map<String, String> hiIN = {
  'term_service': "सेवा की शर्तें",
};
