const Map<String, String> jaJP = {
  'term_service': "利用規約",
};
