const Map<String, String> ruRU = {
  'privacy_policy': "Политика конфиденциальности"
};
