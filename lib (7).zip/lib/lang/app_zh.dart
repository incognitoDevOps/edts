const Map<String, String> zhCH = {
  'privacy_policy': "隐私政策"
};
